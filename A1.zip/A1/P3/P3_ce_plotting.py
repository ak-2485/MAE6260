import matplotlib.pyplot as plt
import numpy as np

# scrub output files for energy
energy_out = []
for x in range(10,30,5) :
    file = open('Si.scf.'+ str(x) +'.out','r')
    for _, line in enumerate(file) :
        if '!' in line: 
          enrg = ''.join(c for c in line if (c.isdigit() or c=='-' or c=='.'))
          energy_out.append(float(enrg))
          break
    file.close()

ecut = [x for x in range(10,30,5)]
# plot energy
cnvg_e = sum(energy_out[2:],0)/len(energy_out[2:])
stre = float(f'{cnvg_e:.3f}')
plt.plot(ecut,[cnvg_e for x in range(0,len(ecut))],'r-',label=str(stre))
plt.plot(ecut,energy_out,'b.', label="Si64")
plt.plot(ecut,energy_out,color='cornflowerblue',linestyle='dashed')
plt.xlabel(r"Wavefunction cutoff (Ry)")
plt.ylabel(r"Total energy (Ry)")
plt.grid()
plt.legend(ncol=2,loc="best",fontsize=14)
plt.tight_layout()
plt.savefig('P3_cutoff_convergence.png')
