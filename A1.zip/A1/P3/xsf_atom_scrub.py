import matplotlib.pyplot as plt
import numpy as npa
import sys

name = sys.argv[1]
# scrub output files for energy
file = open(name,'r')
num = 0
for lnum, line in enumerate(file) :
    if 'ATOM' in line:   
        num = lnum
        print(num)
file.close()

file = open(name,'r')
atoms_out  = list(enumerate(file))[num+1:num+65]
out = []
for x in atoms_out:
    out.append(x[1])
            #confg = ''.join(c for c in line if (c.isdigit() or c=='-' or c=='.')
print(out)
file.close()

"""
ecut = [x for x in range(10,150,10)]
# plot energy
cnvg_e = sum(energy_out[2:],0)/len(energy_out[2:])
stre = float(f'{cnvg_e:.3f}')
plt.plot(ecut,[cnvg_e for x in range(0,len(ecut))],'r-',label=str(stre))
plt.plot(ecut,energy_out,'b.', label="Si64")
plt.plot(ecut,energy_out,color='cornflowerblue',linestyle='dashed')
plt.xlabel(r"Wavefunction cutoff (Ry)")
plt.ylabel(r"Total energy (Ry)")
plt.grid()
plt.legend(ncol=2,loc="best",fontsize=14)
plt.tight_layout()
plt.savefig('P3_cutoff_convergence.png') """
