import matplotlib.pyplot as plt
import numpy as np
import sys

name = sys.argv[1]
# scrub output file for energy
energy = []
file = open(name,'r')
for _, line in enumerate(file) :
    if 'Ry' in line and 'total energy' in line: 
        enrg = ''.join(c for c in line if (c.isdigit() or c=='-' or c=='.'))
        energy.append(float(enrg))
file.close()
print(energy)
#plot energy
cnvg_e = energy[len(energy)-1]
plt.plot((range(0,len(energy))),[cnvg_e for x in range(0,len(energy))],'r-',label=str(cnvg_e))
plt.plot((range(0,len(energy))),energy,'b.', label="Si65")
plt.plot((range(0,len(energy))),energy,color='cornflowerblue',linestyle='dashed')
plt.xlabel(r"Iteration number")
plt.ylabel(r"Total energy (Ry)")
plt.grid()
plt.legend(ncol=1,loc="best",fontsize=14)
plt.tight_layout()
plt.savefig(name[:-5]+'.png')
