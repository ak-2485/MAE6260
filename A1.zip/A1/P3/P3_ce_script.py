import os

# scrub xsf file for atom locs
name = "perfect_crystal_64.xsf"
file = open(name,'r')
num = 0
for lnum, line in enumerate(file) :
    if 'ATOM' in line:
        num = lnum
        print(num)
file.close()
file = open(name,'r')
atoms_out  = list(enumerate(file))[num+1:num+65]
lpos1 = []
for x in atoms_out:
    lpos1.append(x[1])
file.close()

# create qe input files for cutoff convergence test
# and run test
ecut_min = 10
ecut_max = 40
step     = 5
for x in range(ecut_min, ecut_max + step, step):
    print("runnning ecutoff = " + str(x))
    in_f = open('Si.scf.'+ str(x) +'.in','w')

    lcal = "calculation = 'scf'\n"
    lrst = "restart_mode = 'from_scratch'\n"
    lpre = "prefix = 'Si64'\n"
    ldir = "pseudo_dir = './'\n"
    control = ["&control\n",lcal,lrst,lpre,ldir,"/\n"]

    lbrav  = "ibrav = 0,\n"
    lnum   = "nat = 64, ntyp = 1,\n"
    lcut   = "ecutwfc = " + str(x) + "\n"
    system = ["&system\n",lbrav,lnum,lcut,"/\n"]

    electrons = ["&electrons\n","mixing_beta = 0.7\n","/\n"]

    lspec = ["ATOMIC_SPECIES\n", "Si 28.086 Si.pbe-rrkj.UPF\n"]
    lpos0 = ["ATOMIC_POSITIONS (angstrom)\n"]
    lpos  = lpos0 + lpos1 #lpos1 defined at top of file
    lprm0 = ["CELL_PARAMETERS (angstrom)\n"]
    lprm1 = ["10.935971882    0.0000000000    0.0000000000\n"]
    lprm2 = ["0.0000000000    10.935971882    0.0000000000\n"]
    lprm3 = ["0.0000000000    0.0000000000    10.935971882\n"]
    lprm  = lprm0 + lprm1 + lprm2 + lprm3
    lpts  = ["K_POINTS (automatic)\n", "4 4 4 1 1 1\n"]
    bot   = lspec + lpos + lprm + lpts + ["EOF\n"]

    write_list = control + system + electrons + bot
    in_f.writelines(write_list)

    in_f.close()

    os.system("pw.x -in Si.scf."+str(x)+".in > Si.scf."+str(x)+".out")


