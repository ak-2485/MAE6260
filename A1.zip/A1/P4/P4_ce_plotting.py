import matplotlib.pyplot as plt
import numpy as np
import matplotlib.colors as mcolors


# scrub output files for energy
energy_out = []
for x in range(10,150,10) :
    file = open('Al.scf.'+ str(x) +'.out','r')
    for _, line in enumerate(file) :
        if '!' in line: 
          enrg = ''.join(c for c in line if (c.isdigit() or c=='-' or c=='.'))
          energy_out.append(float(enrg))
          break
    file.close()

ecut = [x for x in range(10,150,10)]
cnvg_e = sum(energy_out[2:],0)/len(energy_out[2:])
#plot energy
stre = float(f'{cnvg_e:.3f}')
plt.plot(ecut,[cnvg_e for x in range(0,len(ecut))],'r-',label=str(stre))
plt.plot(ecut,energy_out,'b.', label="Al")
plt.plot(ecut,energy_out,color='cornflowerblue',linestyle='dashed')
plt.xlabel(r"Wavefunction cutoff (Ry)")
plt.ylabel(r"Total energy (Ry)")
plt.grid()
plt.legend(ncol=2,loc="best",fontsize=14)
plt.tight_layout()
plt.savefig('p4_cutoff_convergence.png')
