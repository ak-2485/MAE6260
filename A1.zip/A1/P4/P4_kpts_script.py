import os

kpoints = [2,4,6,8,10,12,14,16]
for k_x in kpoints:
    print("runnning kpoint= " + str(k_x))
    in_f = open('Al.scf.kpts.'+ str(k_x) +'.in','w')

    lcal = "calculation = 'scf'\n"
    lrst = "restart_mode = 'from_scratch'\n"
    lpre = "prefix = 'Al'\n"
    lst  = "tstress = .true.\n"
    lpr  = "tprnfor = .true.\n"
    ldir = "pseudo_dir = './'\n"
    control = ["&control\n",lcal,lrst,lpre,lst,lpr,ldir,"/\n"]

    lbrav  = "ibrav = 2,\n"
    ldim   = "celldm(1) = 5.000,\n"
    lnum   = "nat = 1, ntyp = 1,\n"
    lcut   = "ecutwfc =  20\n"
    locc   = "occupations = 'smearing'\n"
    lsmr   = "smearing = 'methfessel-paxton'\n"
    ldeg   = "degauss = 0.05\n"
    system = ["&system\n",lbrav,ldim,lnum,lcut,locc,lsmr,ldeg,"/\n"]

    electrons = ["&electrons\n","mixing_beta = 0.7\n","/\n"]

    lspec = ["ATOMIC_SPECIES\n", "Al 26.981 Al.pbe-n-kjpaw_psl.1.0.0.UPF\n"]
    lpos  = ["ATOMIC_POSITIONS (alat)\n","Al 0.0 0.0 0.0\n"]
    k     = str(k_x) + " " 
    lpts  = ["K_POINTS (automatic)\n", k + k + k + "0 0 0\n"]
    bot   = lspec + lpos + lpts + ["EOF\n"]

    write_list = control + system + electrons + bot
    in_f.writelines(write_list)

    in_f.close()

    os.system("pw.x -in Al.scf.kpts."+str(k_x)+".in > Al.scf.kpts."+str(k_x)+".out")


