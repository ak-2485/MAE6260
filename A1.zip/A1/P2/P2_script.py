import os

kpoints = [2,4,6,8,10,12,14,16]
for k_x in kpoints:
    print("runnning kpoint= " + str(k_x))
    in_f = open('Si.scf.'+ str(k_x) +'.in','w')

    lcal = "calculation = 'scf'\n"
    lrst = "restart_mode = 'from_scratch'\n"
    lpre = "prefix = 'Si2'\n"
    ldir = "pseudo_dir = './'\n"
    control = ["&control\n",lcal,lrst,lpre,ldir,"/\n"]

    lbrav  = "ibrav = 2,\n"
    ldim   = "celldm(1) = 10.333,\n"
    lnum   = "nat = 2, ntyp = 1,\n"
    lcut   = "ecutwfc =  10\n"
    system = ["&system\n",lbrav,ldim,lnum,lcut,"/\n"]

    electrons = ["&electrons\n","mixing_beta = 0.7\n","/\n"]

    lspec = ["ATOMIC_SPECIES\n", "Si 28.086 Si.pbe-rrkj.UPF\n"]
    lpos  = ["ATOMIC_POSITIONS (alat)\n","Si 0.0 0.0 0.0\n","Si 0.25 0.25 0.25\n"]
    k     = str(k_x) + " " 
    lpts  = ["K_POINTS (automatic)\n", k + k + k + "1 1 1\n"]
    bot   = lspec + lpos + lpts + ["EOF\n"]

    write_list = control + system + electrons + bot
    in_f.writelines(write_list)

    in_f.close()

    os.system("pw.x -in Si.scf."+str(k_x)+".in > Si.scf."+str(k_x)+".out")


